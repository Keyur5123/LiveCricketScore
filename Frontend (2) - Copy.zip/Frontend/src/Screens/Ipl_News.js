import React from 'react';

function Ipl_News(props) {
    return (
        <div>
            This is the Ipl news screen.
        </div>
    );
}

export default Ipl_News;