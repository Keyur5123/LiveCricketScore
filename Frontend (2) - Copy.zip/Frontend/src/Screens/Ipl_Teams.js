import React from 'react';

function Ipl_Teams(props) {
    return (
        <div>
            This is the screen on which displaying the total teams details with it's players.  
        </div>
    );
}

export default Ipl_Teams;